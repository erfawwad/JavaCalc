# Calculator
Very basic calculator application created by Java Swing.
# Screenshots
![](Screenshot/Basic.png) ![](Screenshot/Scientific.png)
# Requirements 🔧
* Java version 8 or higher.
# Installation 🔌
1) Press the Fork button (located on the top right corner of the page) to save copy of this project on your account.

2) Download the repository files (project) from the download section or clone this project by typing in the bash the following command:
   git clone https://github.com/AdishiSood/Java-Calculator

 # Contributing 💡
If you want to contribute to this project and make it better with new ideas, your pull request is very welcomed. If you find any issue just put it in the repository issue section.
# Thank You!
Please ⭐️ this repo and share it with others
